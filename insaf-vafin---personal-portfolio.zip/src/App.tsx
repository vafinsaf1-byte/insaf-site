import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Github, 
  Mail, 
  Send, 
  ExternalLink, 
  Download, 
  Globe, 
  Briefcase, 
  FileText, 
  ChevronRight,
  Menu,
  X,
  Twitter,
  Linkedin,
  Rocket,
  Hash,
  Phone,
  MessageCircle,
  MessageSquare,
  Share2
} from 'lucide-react';
import { cn } from './lib/utils';

// --- Types ---

interface Project {
  title: string;
  description: string;
  type: 'SaaS' | 'Telegram' | 'Service' | 'IoT' | 'Other';
  link?: string;
  tags: string[];
  logoUrl?: string;
}

interface Solution {
  id: string;
  title: string;
  category: string;
  description: string;
  downloadUrl: string;
  linkText: string;
}

interface Social {
  name: string;
  icon: React.ReactNode;
  url: string;
  label: string;
}

// --- Data ---

const PROJECTS: Project[] = [
  {
    title: "Rightech IoT Core (RIC)",
    description: "Первая зарегистрированная в России платформа Интернета Вещей. Универсальное решение для быстрого создания IoT-систем без ограничений в оборудовании и написания кода.",
    type: "IoT",
    tags: ["IoT", "Cloud", "No-code"],
    link: "https://rightech.io/ru",
    logoUrl: "https://yt3.googleusercontent.com/0sPkrX4wdstPij2twNFiatNpnUp48fNHSK5PIrqz-zFMgjBBGqL6H6bySa6r62tnq2hH0L_givY=s900-c-k-c0x00ffffff-no-rj"
  }
];

const SOLUTIONS: Solution[] = [
  {
    id: "01",
    title: "Генератор геозон для RIC",
    category: "Desktop",
    description: "Утилита для автоматизации создания и массового импорта геозон в платформу Rightech IoT Core. Упрощает работу с картографическими данными.",
    downloadUrl: "https://disk.360.yandex.ru/d/vOeZt0SBT8NkSA",
    linkText: "Яндекс Диск"
  },
  {
    id: "02",
    title: "Консультант по возможностям RIC",
    category: "AI",
    description: "Интеллектуальный помощник на базе LLM, обученный на базе знаний платформы Rightech. Помогает быстро разобраться в функционале и проектировать IoT-сценарии.",
    downloadUrl: "https://notebooklm.google.com/notebook/068a54a0-41ee-4b0d-a184-a6cf7dee0bd1/preview",
    linkText: "NotebookLM"
  },
  {
    id: "03",
    title: "Audio-to-Text Transcriber",
    category: "Desktop",
    description: "Инструмент для автоматической транскрибации аудиофайлов в текст с использованием нейросетей Assembly AI. Идеально для интервью и встреч.",
    downloadUrl: "#",
    linkText: "Скоро"
  }
];

const SOCIALS: Social[] = [
  { name: "Telegram", icon: <Send className="w-5 h-5" />, url: "https://t.me/", label: "@vafinsaf" },
  { name: "VK", icon: <Share2 className="w-5 h-5" />, url: "https://vk.com/", label: "insaf.vafin" },
  { name: "GitHub", icon: <Github className="w-5 h-5" />, url: "https://github.com/", label: "insaf-v" },
  { name: "Twitter", icon: <Twitter className="w-5 h-5" />, url: "https://twitter.com/", label: "@insaf" },
];

// --- Components ---

// --- Flip Component for Contact ---
const FlipContact = ({ 
  label,
  value, 
  icon: Icon,
  href
}: { 
  label: string;
  value: string; 
  icon: any;
  href?: string;
}) => {
  const [isFlipped, setIsFlipped] = useState(false);

  return (
    <div 
      className="perspective-1000 w-full h-32 cursor-pointer"
      onClick={() => setIsFlipped(!isFlipped)}
    >
      <motion.div
        className="relative w-full h-full transition-all duration-500 preserve-3d"
        animate={{ rotateY: isFlipped ? 180 : 0 }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
      >
        {/* Front: Icon/Label Look */}
        <div className="absolute inset-0 backface-hidden bg-card-bg border border-border rounded-[24px] flex flex-col items-center justify-center hover:border-accent transition-colors shadow-sm gap-2 select-none">
          <div className="p-3 bg-accent/10 rounded-xl text-accent">
            <Icon size={32} />
          </div>
          <span className="text-[10px] font-black text-text-muted uppercase tracking-[0.2em]">{label}</span>
        </div>

        {/* Back: Revealed Value */}
        <div 
          className="absolute inset-0 backface-hidden [transform:rotateY(180deg)] bg-accent rounded-[24px] flex flex-col items-center justify-center p-4 shadow-xl gap-1"
        >
          <div className="text-[9px] text-white/70 font-black uppercase tracking-widest select-none">{label}</div>
          <div className="text-white text-center w-full overflow-hidden px-2 select-text cursor-auto" onClick={(e) => e.stopPropagation()}>
            <div className="text-[11px] font-black tracking-tight break-all">
              {href ? (
                <a 
                  href={href} 
                  className="hover:underline flex items-center justify-center gap-1" 
                >
                  {value} <ExternalLink size={10} />
                </a>
              ) : value}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

// --- Compact Flip Button for Sidebar ---
const FlipButton = ({ 
  label,
  value, 
  icon: Icon,
  href
}: { 
  label: string;
  value: string; 
  icon: any;
  href?: string;
}) => {
  const [isFlipped, setIsFlipped] = useState(false);

  return (
    <div 
      className="perspective-1000 w-full h-[52px] cursor-pointer"
      onClick={() => setIsFlipped(!isFlipped)}
    >
      <motion.div
        className="relative w-full h-full transition-all duration-500 preserve-3d"
        animate={{ rotateY: isFlipped ? 180 : 0 }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
      >
        {/* Front: Blue Button Look */}
        <div className="absolute inset-0 backface-hidden bg-accent text-white rounded-xl font-black uppercase tracking-widest flex items-center justify-center gap-3 text-sm shadow-lg hover:bg-neutral-900 transition-all select-none px-4">
          <Icon size={16} /> {label} Email
        </div>

        {/* Back: Revealed Email (Compact) */}
        <div 
          className="absolute inset-0 backface-hidden [transform:rotateY(180deg)] bg-neutral-900 text-white rounded-xl flex items-center justify-center shadow-xl border border-white/10"
        >
          <div 
            className="w-full text-center px-2 select-text cursor-auto overflow-hidden truncate italic text-[11px] font-bold"
            onClick={(e) => e.stopPropagation()}
          >
            {value}
          </div>
        </div>
      </motion.div>
    </div>
  );
};

const Sidebar = () => (
  <aside className="w-full lg:w-[320px] flex flex-col lg:fixed lg:h-[calc(100vh-48px)]">
    {/* Consolidated Compact Profile Card */}
    <div className="bg-card-bg border border-border rounded-[28px] p-6 text-center shadow-md relative overflow-hidden group flex-1 flex flex-col">
      {/* Photo Area - Compacted */}
      <div className="relative w-full h-[300px] mb-6">
        <div className="w-full h-full bg-neutral-100 dark:bg-neutral-800 rounded-2xl overflow-hidden shadow-inner border border-border/50">
          <img 
            src="https://sun1-25.userapi.com/s/v1/ig2/Jzh34XghdcwKpiNsoBwC5CSacqtMP3HorWF1W8ch_7ycWs1fHK_pN27GOEFU1P5rX6IwVgtuKaXqdkl2V-PdShjQ.jpg?quality=95&crop=461,481,799,799&as=32x32,48x48,72x72,108x108,160x160,240x240,360x360,480x480,540x540,640x640,720x720&ava=1&cs=200x200" 
            alt="Инсаф Вафин"
            className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-1000 scale-105 group-hover:scale-100"
            referrerPolicy="no-referrer"
          />
        </div>
      </div>

      <div className="flex-1">
        <h1 className="text-2xl font-black text-text-main mb-3 tracking-tighter uppercase italic leading-none">Инсаф Вафин</h1>
        
        <div className="space-y-1 mb-6">
          <p className="text-[11px] text-text-muted font-black uppercase tracking-widest leading-none">Руководитель отдела</p>
          <p className="text-[11px] text-text-muted font-black uppercase tracking-widest leading-none">управления проектами</p>
          <p className="text-[12px] text-accent font-black uppercase tracking-widest leading-none pt-1">Rightech</p>
        </div>
        
        <div className="text-[11px] text-text-main font-semibold leading-relaxed px-2 py-3 border-y border-border/50 mb-4 italic">
          Специализируюсь на создании масштабируемых решений, автоматизации бизнес-процессов.
        </div>

        <div className="flex flex-col items-center mb-6">
          <span className="text-[9px] font-bold text-text-muted uppercase tracking-[0.2em] mb-2">Science Index</span>
          <a 
            href="https://elibrary.ru/author_counter_click.asp?id=1192895" 
            target="_blank" 
            rel="noopener noreferrer"
            className="hover:shadow-md transition-shadow bg-white p-1 rounded-lg border border-border flex items-center justify-center"
          >
            <img 
              src={`https://elibrary.ru/author_counter.aspx?id=1192895&rand=${Math.random()}`} 
              title="Профиль автора в Science Index" 
              className="h-[28px] w-auto border-0"
              referrerPolicy="no-referrer"
            />
          </a>
        </div>
      </div>

      <div className="mt-auto">
        <FlipButton 
          label="Contact"
          value="vafinsaf1@gmail.com"
          icon={Mail}
          href="mailto:vafinsaf1@gmail.com"
        />
      </div>
    </div>
  </aside>
);

const SectionHeader = ({ title, icon }: { title: string; icon?: React.ReactNode }) => (
  <div className="flex items-center gap-4 mb-8">
    <div className="p-2.5 bg-accent/10 rounded-xl text-accent">
      {icon}
    </div>
    <h2 className="text-2xl font-black text-text-main whitespace-nowrap uppercase tracking-tighter">
      {title}
    </h2>
    <div className="h-[2px] bg-border flex-1" />
  </div>
);

const ProjectCard = ({ project }: { project: Project; key?: React.Key }) => (
  <a 
    href={project.link}
    target="_blank"
    rel="noopener noreferrer"
    className="bg-card-bg border border-border rounded-3xl overflow-hidden transition-all hover:shadow-2xl hover:border-accent group flex flex-col md:flex-row h-full"
  >
    {/* 1/3 Logo Reveal Area */}
    <div className="w-full md:w-1/3 bg-neutral-50 dark:bg-neutral-900 flex items-center justify-center border-b md:border-b-0 md:border-r border-border p-8 group-hover:bg-accent/5 transition-colors">
      <div className="w-20 h-20 bg-white dark:bg-neutral-800 rounded-3xl shadow-sm flex items-center justify-center text-accent font-black text-2xl group-hover:scale-110 transition-transform border border-border/50 overflow-hidden p-2">
        {project.logoUrl ? (
          <img 
            src={project.logoUrl} 
            alt={project.title} 
            className="w-full h-full object-contain"
            referrerPolicy="no-referrer"
          />
        ) : (
          project.type === 'SaaS' ? <Rocket size={28} /> : project.type === 'Telegram' ? <Send size={28} /> : <Hash size={28} />
        )}
      </div>
    </div>
    
    <div className="flex-1 p-8 flex flex-col justify-center">
      <div className="text-[10px] font-black text-accent uppercase tracking-[0.2em] mb-3">
        {project.type}
      </div>
      <h3 className="text-xl font-black text-text-main mb-3 uppercase tracking-tight flex items-center justify-between">
        {project.title}
        <ExternalLink size={18} className="text-text-muted opacity-0 group-hover:opacity-100 transition-all transform translate-x-2 group-hover:translate-x-0" />
      </h3>
      <p className="text-[13px] text-text-muted leading-relaxed font-semibold line-clamp-3">
        {project.description}
      </p>
    </div>
  </a>
);

// --- Flip Component for Contact ---
interface CatalogItemProps {
  solution: Solution;
  key?: React.Key;
}

const CatalogItem = ({ solution }: CatalogItemProps) => (
  <tr className="hover:bg-blue-50/30 transition-colors group">
    <td className="px-6 py-5 align-top font-bold text-text-main uppercase tracking-tight text-sm">
      {solution.title}
    </td>
    <td className="px-6 py-5 align-top">
      <p className="text-sm text-text-muted leading-relaxed max-w-sm">
        {solution.description}
      </p>
    </td>
    <td className="px-6 py-5 align-top">
      <span className="bg-[#EFF6FF] text-[#1E40AF] px-3 py-1 rounded-md text-[10px] font-black uppercase tracking-widest">
        {solution.category}
      </span>
    </td>
    <td className="px-6 py-5 align-top text-right">
      <a
        href={solution.downloadUrl}
        target="_blank" 
        rel="noopener noreferrer"
        className="inline-flex items-center gap-2 text-accent text-sm font-bold hover:underline"
      >
        <ExternalLink size={16} /> <span className="hidden md:inline">{solution.linkText}</span>
      </a>
    </td>
  </tr>
);

export default function App() {
  return (
    <div className="min-h-screen p-6 lg:p-12 selection:bg-accent selection:text-white">
      <div className="max-w-[1300px] mx-auto flex flex-col lg:flex-row gap-12">
        <Sidebar />

        <main className="flex-1 space-y-16 lg:ml-[360px]">
          {/* Projects Section */}
          <section id="projects">
            <SectionHeader title="Ключевые проекты" icon={<Briefcase size={22} />} />
            <div className="grid grid-cols-1 gap-6">
              {PROJECTS.map((p, i) => (
                <ProjectCard key={i} project={p} />
              ))}
            </div>
          </section>

          {/* Catalog Section */}
          <section id="catalog" className="flex flex-col min-h-0">
            <SectionHeader title="Каталог решений" icon={<Hash size={22} />} />
            <div className="bg-card-bg border border-border rounded-3xl overflow-hidden shadow-sm">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse min-w-[600px]">
                  <thead>
                    <tr className="bg-neutral-50 dark:bg-neutral-900/50 border-b border-border">
                      <th className="px-8 py-5 text-[12px] font-black text-text-muted uppercase tracking-[0.2em]">Решение</th>
                      <th className="px-8 py-5 text-[12px] font-black text-text-muted uppercase tracking-[0.2em]">Описание</th>
                      <th className="px-8 py-5 text-[12px] font-black text-text-muted uppercase tracking-[0.2em]">Тип</th>
                      <th className="px-8 py-5 text-right text-[12px] font-black text-text-muted uppercase tracking-[0.2em]">Доступ</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border/50">
                    {SOLUTIONS.map((s) => (
                      <CatalogItem key={s.id} solution={s} />
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </section>

          {/* Social Networks Section */}
          <section id="socials">
            <SectionHeader title="Социальные сети" icon={<Share2 size={22} />} />
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <a 
                href="https://m.tenchat.ru/u/LTH8NKeg" 
                target="_blank" 
                rel="noopener noreferrer"
                className="group relative bg-card-bg border border-border rounded-3xl p-8 flex items-center gap-6 hover:border-accent hover:shadow-xl transition-all"
              >
                <div className="w-14 h-14 bg-accent/10 rounded-2xl flex items-center justify-center text-accent group-hover:bg-accent group-hover:text-white transition-all">
                  <Briefcase size={28} />
                </div>
                <div>
                  <div className="text-[10px] font-black text-text-muted uppercase tracking-[0.2em] mb-1">Professional</div>
                  <div className="text-xl font-black text-text-main uppercase tracking-tight">TenChat</div>
                </div>
                <ExternalLink size={20} className="absolute top-6 right-6 text-text-muted opacity-0 group-hover:opacity-100 transition-all" />
              </a>

              <a 
                href="https://set.ki/4XxXFQt" 
                target="_blank" 
                rel="noopener noreferrer"
                className="group relative bg-card-bg border border-border rounded-3xl p-8 flex items-center gap-6 hover:border-accent hover:shadow-xl transition-all"
              >
                <div className="w-14 h-14 bg-accent/10 rounded-2xl flex items-center justify-center text-accent group-hover:bg-accent group-hover:text-white transition-all">
                  <Share2 size={28} />
                </div>
                <div>
                  <div className="text-[10px] font-black text-text-muted uppercase tracking-[0.2em] mb-1">Network</div>
                  <div className="text-xl font-black text-text-main uppercase tracking-tight">Сетка</div>
                </div>
                <ExternalLink size={20} className="absolute top-6 right-6 text-text-muted opacity-0 group-hover:opacity-100 transition-all" />
              </a>

              <a 
                href="https://vk.com/vafin_insaf" 
                target="_blank" 
                rel="noopener noreferrer"
                className="group relative bg-card-bg border border-border rounded-3xl p-8 flex items-center gap-6 hover:border-accent hover:shadow-xl transition-all"
              >
                <div className="w-14 h-14 bg-accent/10 rounded-2xl flex items-center justify-center text-accent group-hover:bg-accent group-hover:text-white transition-all">
                  <span className="text-2xl font-black">VK</span>
                </div>
                <div>
                  <div className="text-[10px] font-black text-text-muted uppercase tracking-[0.2em] mb-1">Social</div>
                  <div className="text-xl font-black text-text-main uppercase tracking-tight">ВКонтакте</div>
                </div>
                <ExternalLink size={20} className="absolute top-6 right-6 text-text-muted opacity-0 group-hover:opacity-100 transition-all" />
              </a>
            </div>
          </section>

          {/* Contacts Section */}
          <section id="contact">
            <SectionHeader title="Связь" icon={<Globe size={22} />} />
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <FlipContact 
                label="Телефон"
                value="+7 (919) 686 6816" 
                icon={Phone} 
                href="tel:+79196866816"
              />
              <FlipContact 
                label="Telegram"
                value="@Vafinsaf" 
                icon={Send} 
                href="https://t.me/vafinsaf"
              />
              <FlipContact 
                label="MAX"
                value="+7 (919) 686 6816" 
                icon={MessageSquare} 
                href="tel:+79196866816"
              />
            </div>
          </section>

          <footer className="pt-12 border-t border-border flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="text-xl font-black text-text-main uppercase tracking-tighter italic">Инсаф Вафин</div>
            <p className="text-[11px] text-text-muted font-bold tracking-[0.3em] uppercase">
              © {new Date().getFullYear()} • Strategic Portfolio
            </p>
          </footer>
        </main>
      </div>
    </div>
  );
}
